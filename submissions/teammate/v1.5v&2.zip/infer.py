"""
infer.py — Optimized inference for Baidu CTI 2026 Competition.

Based on the official v1.3 pipeline with:
  - Optimized RepEncoder (F.embedding_bag + single-value fast path)
  - Block-causal TransformerEncoder (per-user FlashAttention)
  - SMoE with numerically stable gating (logsumexp)
  - Batch pruning & metadata annotation for throughput
  - Early-exit for no-prediction batches
  - Multi-location path resolution for robustness
  - GRAB model fallback for non-official checkpoints

All required interfaces maintained:
  load_sample_files, CTRTestSeqDataset, make_collate_fn,
  load_model, move_batch_to_device, model(batch)->(logits, moe_loss)
"""

from __future__ import annotations

import argparse
import csv
import json
import math
import pickle
import sys
from collections import defaultdict
from pathlib import Path
from typing import Any, Callable, Dict, Iterable, List, Mapping, Sequence, Tuple, Union

import numpy as np

try:
    import torch
    import torch.nn as nn
    import torch.nn.functional as F
except Exception as exc:  # pragma: no cover - judge environment should provide torch
    torch = None
    nn = None
    F = None
    _TORCH_IMPORT_ERROR = exc
else:
    _TORCH_IMPORT_ERROR = None


LOGID_KEYS = ("logid", "log_id", "id", "sample_id")
USER_KEYS = ("user_id", "uid", "userid")
SEQUENCE_KEYS = ("user_seq", "history", "hist", "histories", "seq", "features", "feasigns")
ITEM_KEYS = ("item_id", "ad_id", "creative_id", "cid", "aid")
MODEL_KEYS = ("model", "net", "module")
STATE_DICT_KEYS = ("model_state_dict", "state_dict", "net_state_dict")


def _require_torch() -> None:
    if torch is None:
        raise RuntimeError(f"PyTorch is required by infer.py: {_TORCH_IMPORT_ERROR}")


# ==============================================================================
# Helper utilities
# ==============================================================================

def _as_int(value: Any, default: int = 0) -> int:
    if value is None:
        return default
    if isinstance(value, (np.integer, int)):
        return int(value)
    if isinstance(value, (np.floating, float)):
        return int(value)
    if isinstance(value, bytes):
        value = value.decode("utf-8", errors="ignore")
    if isinstance(value, str):
        value = value.strip()
        if not value:
            return default
        try:
            return int(value)
        except ValueError:
            return abs(hash(value)) % 2_147_483_647
    return abs(hash(repr(value))) % 2_147_483_647


def _tokenize_scalar(value: Any) -> List[int]:
    if value is None:
        return []
    if isinstance(value, bytes):
        value = value.decode("utf-8", errors="ignore")
    if isinstance(value, str):
        text = value.strip()
        if not text:
            return []
        if text[0] in "[{" and text[-1] in "]}":
            try:
                return _flatten_ints(json.loads(text))
            except Exception:
                pass
        for sep in (",", "|", ";"):
            text = text.replace(sep, " ")
        return [_as_int(part) for part in text.split() if part]
    return [_as_int(value)]


def _flatten_ints(value: Any) -> List[int]:
    if value is None:
        return []
    if isinstance(value, Mapping):
        out: List[int] = []
        for key in sorted(value):
            out.extend(_flatten_ints(value[key]))
        return out
    if isinstance(value, np.ndarray):
        return [_as_int(x) for x in value.reshape(-1).tolist()]
    if isinstance(value, (list, tuple, set)):
        out: List[int] = []
        for item in value:
            out.extend(_flatten_ints(item))
        return out
    return _tokenize_scalar(value)


def _first_key(record: Mapping[str, Any], keys: Sequence[str]) -> Any:
    for key in keys:
        if key in record:
            return record[key]
    lowered = {str(k).lower(): k for k in record}
    for key in keys:
        if key in lowered:
            return record[lowered[key]]
    return None


# ==============================================================================
# Generic data loading
# ==============================================================================

def _records_from_object(obj: Any) -> Iterable[Mapping[str, Any]]:
    if isinstance(obj, Mapping):
        rows = obj.get("data") or obj.get("records") or obj.get("samples")
        if rows is not None:
            yield from _records_from_object(rows)
            return
        if all(hasattr(v, "__len__") and not isinstance(v, (str, bytes, Mapping)) for v in obj.values()):
            keys = list(obj.keys())
            try:
                n = len(obj[keys[0]])
            except Exception:
                yield obj
                return
            for i in range(n):
                yield {k: obj[k][i] for k in keys}
        else:
            yield obj
    elif isinstance(obj, np.ndarray):
        if obj.dtype.names:
            for row in obj:
                yield {name: row[name] for name in obj.dtype.names}
        else:
            for row in obj.tolist():
                if isinstance(row, Mapping):
                    yield row
    elif isinstance(obj, (list, tuple)):
        for row in obj:
            if isinstance(row, Mapping):
                yield row


def _iter_records(path: Path) -> Iterable[Mapping[str, Any]]:
    suffix = path.suffix.lower()
    if suffix in {".jsonl", ".jl"}:
        with path.open("r", encoding="utf-8") as f:
            for line in f:
                line = line.strip()
                if line:
                    obj = json.loads(line)
                    if isinstance(obj, Mapping):
                        yield obj
        return
    if suffix == ".json":
        with path.open("r", encoding="utf-8") as f:
            yield from _records_from_object(json.load(f))
        return
    if suffix in {".csv", ".tsv"}:
        delimiter = "\t" if suffix == ".tsv" else ","
        with path.open("r", encoding="utf-8", newline="") as f:
            yield from csv.DictReader(f, delimiter=delimiter)
        return
    if suffix in {".pkl", ".pickle"}:
        with path.open("rb") as f:
            yield from _records_from_object(pickle.load(f))
        return
    if suffix == ".npz":
        obj = np.load(path, allow_pickle=True)
        keys = list(obj.keys())
        if keys:
            for i in range(len(obj[keys[0]])):
                yield {k: obj[k][i].item() if getattr(obj[k][i], "shape", None) == () else obj[k][i] for k in keys}
        return
    if suffix == ".npy":
        yield from _records_from_object(np.load(path, allow_pickle=True))
        return
    if suffix == ".pt" and torch is not None:
        yield from _records_from_object(torch.load(path, map_location="cpu"))
        return
    if suffix == ".parquet":
        try:
            import pandas as pd
        except Exception:
            return
        for row in pd.read_parquet(path).to_dict("records"):
            yield row


def _features_from_record(record: Mapping[str, Any], max_ctx_len: int | None = None) -> List[int]:
    features: List[int] = []
    for key in SEQUENCE_KEYS:
        value = _first_key(record, (key,))
        if value is not None:
            features.extend(_flatten_ints(value))
    item = _first_key(record, ITEM_KEYS)
    if item is not None:
        features.extend(_flatten_ints(item))
    if not features:
        ignored = set(LOGID_KEYS) | set(USER_KEYS)
        for key, value in record.items():
            if str(key).lower() not in ignored:
                features.extend(_flatten_ints(value))
    features = [abs(int(x)) for x in features if int(x) >= 0]
    if max_ctx_len is not None and max_ctx_len > 0:
        features = features[-max_ctx_len:]
    return features or [0]


# ==============================================================================
# Official CSV support
# ==============================================================================

def _detect_has_clk(file_path: Path) -> bool:
    with Path(file_path).open("r", encoding="utf-8") as f:
        for line in f:
            line = line.strip()
            if not line:
                continue
            parts = line.split(",")
            if len(parts) >= 5:
                return ":" not in parts[4]
            return False
    return False


def _load_official_csv_sample_files(sample_files: Sequence[Path]) -> Tuple[Dict[int, Dict[str, Any]], Dict[int, List[int]]]:
    item_dict: Dict[int, Dict[str, Any]] = {}
    user_logs: Dict[int, List[Tuple[int, int]]] = defaultdict(list)
    for sample_file in sorted(Path(f) for f in sample_files):
        has_clk = _detect_has_clk(sample_file)
        min_parts = 5 if has_clk else 4
        with sample_file.open("r", encoding="utf-8") as f:
            for line in f:
                line = line.strip()
                if not line:
                    continue
                parts = line.split(",")
                if len(parts) < min_parts:
                    continue
                try:
                    logid = int(parts[0])
                    userid = int(parts[1])
                    adid = int(parts[2])
                    if has_clk:
                        clk = int(parts[3])
                        timestamp = int(parts[4])
                        feat_start = 5
                    else:
                        clk = 0
                        timestamp = int(parts[3])
                        feat_start = 4
                except ValueError:
                    continue
                signs = []
                slots = []
                for pair in parts[feat_start:]:
                    if ":" not in pair:
                        continue
                    sign, slot = pair.split(":", 1)
                    try:
                        signs.append(int(sign))
                        slots.append(int(slot))
                    except ValueError:
                        continue
                item_dict[logid] = {
                    "logid": logid,
                    "userid": userid,
                    "adid": adid,
                    "clk": clk,
                    "timestamp": timestamp,
                    "signs": np.asarray(signs, dtype=np.int64),
                    "slots": np.asarray(slots, dtype=np.int64),
                }
                user_logs.setdefault(userid, []).append((timestamp, logid))
    user_seq: Dict[int, List[int]] = {}
    for userid, logs in user_logs.items():
        logs.sort(key=lambda x: x[0])
        user_seq[userid] = [logid for _, logid in logs]
    return item_dict, user_seq


# ==============================================================================
# Cached batch support
# ==============================================================================

def _looks_like_cached_batch_file(path: Path) -> bool:
    name = path.name.lower()
    return path.suffix.lower() == ".pt" and ("shard" in name or "batch" in name or "cached" in str(path).lower())


def _load_cached_batches_from_files(files: Sequence[Path]) -> List[Mapping[str, Any]]:
    _require_torch()
    batches: List[Mapping[str, Any]] = []
    for file_path in sorted(Path(p) for p in files):
        obj = torch.load(file_path, map_location="cpu", weights_only=False)
        if isinstance(obj, Mapping):
            if {"logid", "pred_mask"}.issubset(obj.keys()):
                batches.append(obj)
            else:
                nested = obj.get("batches") or obj.get("data")
                if isinstance(nested, (list, tuple)):
                    batches.extend(x for x in nested if isinstance(x, Mapping))
        elif isinstance(obj, (list, tuple)):
            batches.extend(x for x in obj if isinstance(x, Mapping))
    return batches


def _is_cached_batch(row: Mapping[str, Any]) -> bool:
    return {"logid", "pred_mask"}.issubset(row.keys()) and any(isinstance(k, int) for k in row.keys())


def _merge_offsets(parts: Sequence[Any]) -> Any:
    if not parts:
        return parts
    if torch is not None and all(torch.is_tensor(p) for p in parts):
        out = [parts[0]]
        base = int(parts[0][-1].item())
        for offsets in parts[1:]:
            out.append(offsets[1:] + base)
            base += int(offsets[-1].item())
        return torch.cat(out, dim=0)
    arrays = [np.asarray(p) for p in parts]
    out = [arrays[0]]
    base = int(arrays[0][-1])
    for offsets in arrays[1:]:
        out.append(offsets[1:] + base)
        base += int(offsets[-1])
    return np.concatenate(out, axis=0)


def _concat_values(parts: Sequence[Any]) -> Any:
    if torch is not None and all(torch.is_tensor(p) for p in parts):
        return torch.cat(list(parts), dim=0)
    return np.concatenate([np.asarray(p) for p in parts], axis=0)


def _merge_cached_batches(batch: Sequence[Mapping[str, Any]]) -> Dict[str, Any]:
    if len(batch) == 1:
        return dict(batch[0])
    merged: Dict[str, Any] = {}
    keys = batch[0].keys()
    for key in keys:
        values = [row[key] for row in batch if key in row]
        if not values:
            continue
        first = values[0]
        if isinstance(key, int) and isinstance(first, tuple) and len(first) == 2:
            slot_values = [value[0] for value in values]
            slot_offsets = [value[1] for value in values]
            merged[key] = (_concat_values(slot_values), _merge_offsets(slot_offsets))
        elif key == "user_offsets":
            row_counts = [int(row["logid"].shape[0]) for row in batch]
            out = [values[0]]
            base = row_counts[0]
            for offsets, rows in zip(values[1:], row_counts[1:]):
                out.append(offsets[1:] + base)
                base += rows
            merged[key] = torch.cat(out, dim=0) if torch is not None and all(torch.is_tensor(v) for v in values) else np.concatenate([np.asarray(x) for x in out], axis=0)
        elif torch is not None and all(torch.is_tensor(v) for v in values):
            merged[key] = torch.cat(values, dim=0) if first.ndim > 0 else torch.stack(values, dim=0)
        elif all(isinstance(v, np.ndarray) for v in values):
            merged[key] = np.concatenate(values, axis=0) if first.ndim > 0 else np.stack(values, axis=0)
        else:
            merged[key] = values
    return merged


# ==============================================================================
# Batch pruning & metadata annotation (v1.3 optimizations)
# ==============================================================================

def _make_offsets_like(reference: Any, lengths: Sequence[int]) -> Any:
    offsets = [0]
    total = 0
    for length in lengths:
        total += int(length)
        offsets.append(total)
    if torch is not None and torch.is_tensor(reference):
        return torch.tensor(offsets, dtype=reference.dtype, device=reference.device)
    if isinstance(reference, np.ndarray):
        return np.asarray(offsets, dtype=reference.dtype)
    return offsets


def _slice_rows_first_dim(value: Any, ranges: Sequence[Tuple[int, int]], total_rows: int) -> Any:
    if torch is not None and torch.is_tensor(value) and value.ndim > 0 and int(value.shape[0]) == total_rows:
        return torch.cat([value[start:end] for start, end in ranges], dim=0) if ranges else value[:0]
    if isinstance(value, np.ndarray) and value.ndim > 0 and int(value.shape[0]) == total_rows:
        return np.concatenate([value[start:end] for start, end in ranges], axis=0) if ranges else value[:0]
    if isinstance(value, list) and len(value) == total_rows:
        out: List[Any] = []
        for start, end in ranges:
            out.extend(value[start:end])
        return out
    if isinstance(value, tuple) and len(value) == total_rows:
        out = []
        for start, end in ranges:
            out.extend(value[start:end])
        return tuple(out)
    return value


def _slice_slot_offsets(slot_value: Any, ranges: Sequence[Tuple[int, int]], total_rows: int) -> Any:
    if not (isinstance(slot_value, tuple) and len(slot_value) == 2):
        return slot_value
    values, offsets = slot_value
    if torch is not None and torch.is_tensor(offsets) and offsets.ndim == 1 and int(offsets.numel()) == total_rows + 1:
        parts = []
        offset_parts = [offsets.new_zeros((1,))]
        base = 0
        for start, end in ranges:
            start_value = int(offsets[start].item())
            end_value = int(offsets[end].item())
            if end_value > start_value:
                parts.append(values[start_value:end_value])
            rel = offsets[start + 1:end + 1] - offsets[start] + base
            offset_parts.append(rel)
            base += end_value - start_value
        new_values = torch.cat(parts, dim=0) if parts else values[:0]
        new_offsets = torch.cat(offset_parts, dim=0)
        return new_values, new_offsets
    if isinstance(offsets, np.ndarray) and offsets.ndim == 1 and int(offsets.shape[0]) == total_rows + 1:
        parts = []
        offset_parts = [np.zeros((1,), dtype=offsets.dtype)]
        base = 0
        for start, end in ranges:
            start_value = int(offsets[start])
            end_value = int(offsets[end])
            if end_value > start_value:
                parts.append(values[start_value:end_value])
            rel = offsets[start + 1:end + 1] - offsets[start] + base
            offset_parts.append(rel)
            base += end_value - start_value
        new_values = np.concatenate(parts, axis=0) if parts else values[:0]
        new_offsets = np.concatenate(offset_parts, axis=0)
        return new_values, new_offsets
    return slot_value


def _prune_batch_for_predictions(batch: Mapping[str, Any]) -> Mapping[str, Any]:
    """Drop rows that cannot affect any requested prediction."""
    if "pred_mask" not in batch or "user_offsets" not in batch:
        return batch
    if torch is None:
        return batch
    pred_mask = batch["pred_mask"]
    user_offsets = batch["user_offsets"]
    pred_cpu = pred_mask.detach().cpu().bool() if torch.is_tensor(pred_mask) else torch.as_tensor(pred_mask, dtype=torch.bool)
    offsets_cpu = user_offsets.detach().cpu().long() if torch.is_tensor(user_offsets) else torch.as_tensor(user_offsets, dtype=torch.long)
    total_rows = int(pred_cpu.numel())
    if total_rows == 0 or offsets_cpu.numel() < 2 or int(offsets_cpu[-1].item()) != total_rows:
        return batch
    if not bool(pred_cpu.any().item()):
        no_pred = dict(batch)
        no_pred["_has_predictions"] = False
        return no_pred

    ranges: List[Tuple[int, int]] = []
    for user_idx in range(int(offsets_cpu.numel()) - 1):
        start = int(offsets_cpu[user_idx].item())
        end = int(offsets_cpu[user_idx + 1].item())
        if end <= start:
            continue
        pred_positions = torch.nonzero(pred_cpu[start:end], as_tuple=False).view(-1)
        if pred_positions.numel() == 0:
            continue
        last_pred = start + int(pred_positions[-1].item())
        ranges.append((start, last_pred + 1))
    if not ranges:
        return batch
    kept_rows = sum(end - start for start, end in ranges)
    if kept_rows == total_rows and len(ranges) == int(offsets_cpu.numel()) - 1:
        unchanged = dict(batch)
        unchanged["_has_predictions"] = True
        return unchanged

    pruned: Dict[Any, Any] = {"_has_predictions": True}
    lengths = [end - start for start, end in ranges]
    for key, value in batch.items():
        if key == "user_offsets":
            pruned[key] = _make_offsets_like(value, lengths)
        elif isinstance(key, int):
            pruned[key] = _slice_slot_offsets(value, ranges, total_rows)
        else:
            pruned[key] = _slice_rows_first_dim(value, ranges, total_rows)
    return pruned


def _slot_offsets_to_cpu(offsets: Any) -> torch.Tensor | None:
    if torch is None:
        return None
    if torch.is_tensor(offsets):
        if offsets.ndim != 1:
            return None
        return offsets.detach().cpu().long()
    try:
        tensor = torch.as_tensor(offsets, dtype=torch.long)
    except Exception:
        return None
    return tensor if tensor.ndim == 1 else None


def _annotate_fast_batch_metadata(batch: Mapping[str, Any], max_slot_id: int | None = None) -> Mapping[str, Any]:
    if torch is None or "pred_mask" not in batch:
        return batch
    annotated = dict(batch)
    pred_mask = batch["pred_mask"]
    pred_cpu = pred_mask.detach().cpu().bool() if torch.is_tensor(pred_mask) else torch.as_tensor(pred_mask, dtype=torch.bool)
    pred_index = torch.nonzero(pred_cpu, as_tuple=False).view(-1).long()
    num_predictions = int(pred_index.numel())
    annotated["_has_predictions"] = bool(num_predictions)
    annotated["_num_predictions"] = num_predictions
    annotated["_pred_index"] = pred_index

    total_rows = int(pred_cpu.numel())
    if max_slot_id is None:
        slot_ids = sorted(key for key in batch.keys() if isinstance(key, int))
    else:
        slot_ids = list(range(1, int(max_slot_id) + 1))
    active: List[int] = []
    empty: List[int] = []
    single_value: List[int] = []
    variable: List[int] = []
    for slot_id in slot_ids:
        slot_value = batch.get(slot_id)
        if not (isinstance(slot_value, tuple) and len(slot_value) == 2):
            continue
        offsets = _slot_offsets_to_cpu(slot_value[1])
        if offsets is None or int(offsets.numel()) != total_rows + 1:
            continue
        counts = offsets[1:] - offsets[:-1]
        slot_idx = int(slot_id) - 1
        if int(offsets[-1].item()) == 0:
            empty.append(slot_idx)
        else:
            active.append(slot_idx)
            if bool(torch.all(counts == 1).item()):
                single_value.append(slot_idx)
            else:
                variable.append(slot_idx)
    annotated["_active_slot_indices"] = active
    annotated["_empty_slot_indices"] = empty
    annotated["_single_value_slot_indices"] = single_value
    annotated["_variable_slot_indices"] = variable
    return annotated


def _prepare_official_batch(batch: Mapping[str, Any], max_slot_id: int | None = None) -> Mapping[str, Any]:
    return _annotate_fast_batch_metadata(_prune_batch_for_predictions(batch), max_slot_id=max_slot_id)


def _sequence_causal_mask(seq_info):
    lengths = seq_info[1:] - seq_info[:-1]
    lengths = lengths.view(-1)
    indices = torch.cumsum(torch.ones_like(lengths), dim=0) - 1
    result = torch.repeat_interleave(indices, lengths)
    a = result.view(1, -1) - result.view(-1, 1)
    return torch.tril((a == 0).to(torch.int32)).bool()


# ==============================================================================
# Path resolution helper — searches multiple common locations
# ==============================================================================

def _resolve_path(path: Path, is_dir: bool = False) -> Path | None:
    """Try to resolve a path by searching common data directories.

    Search order:
      1. Original path (absolute or relative to CWD)
      2. CWD / filename
      3. CWD / "data" / filename
      4. CWD / "dataset" / filename
      5. infer.py directory / filename
      6. infer.py directory / "data" / filename
      7. infer.py directory / "dataset" / filename
    """
    if (path.is_dir() if is_dir else path.exists()):
        return path

    name = path.name
    cwd = Path.cwd()

    try:
        infer_dir = Path(__file__).resolve().parent
    except Exception:
        infer_dir = cwd

    candidates = [
        cwd / name,
        cwd / "data" / name,
        cwd / "dataset" / name,
        cwd / "official" / "dataset_cached_probe" / "dataset" / "cached_batches" / name,
        infer_dir / name,
        infer_dir / "data" / name,
        infer_dir / "dataset" / name,
    ]

    for candidate in candidates:
        if (candidate.is_dir() if is_dir else candidate.exists()):
            return candidate

    return None


# ==============================================================================
# Required interface: load_sample_files
# ==============================================================================

def load_sample_files(sample_files_list: Sequence[Union[Path, str]]) -> Tuple[Dict[int, Dict[str, Any]], Dict[int, List[int]]]:
    """Load all sample files and return (item_dict, user_seq).

    Priorities:
      1. Cached batch files (.pt shards) -> returns batches keyed by index
      2. Official CSV format (slot:sign pairs) -> returns structured item_dict
      3. Generic fallback (JSONL/JSON/Pickle/NPZ/NPY/Parquet) -> returns feature lists
    """
    # Normalize paths
    sample_files: List[Path] = []
    for p in sample_files_list:
        if isinstance(p, str):
            sample_files.append(Path(p))
        else:
            sample_files.append(p)

    # Priority 1: cached batch files
    cached_paths: List[Path] = []
    for raw_path in sample_files:
        path = Path(raw_path)
        if path.is_dir():
            cached_paths.extend(p for p in sorted(path.rglob("*.pt")) if _looks_like_cached_batch_file(p))
        elif _looks_like_cached_batch_file(path):
            resolved = _resolve_path(path)
            if resolved is not None:
                cached_paths.append(resolved)
            else:
                print(f"[WARN] load_sample_files: cached batch file not found: {path}", file=sys.stderr)
    if cached_paths:
        return {i: {"cached_batch": batch} for i, batch in enumerate(_load_cached_batches_from_files(cached_paths))}, {"__cached_batches__": []}

    # Priority 2: official CSV files
    csv_files: List[Path] = []
    for raw_path in sample_files:
        path = Path(raw_path)
        if path.is_dir():
            csv_files.extend(p for p in sorted(path.rglob("*.csv")) if p.is_file())
        elif path.suffix.lower() == ".csv":
            resolved = _resolve_path(path)
            if resolved is not None:
                csv_files.append(resolved)
            else:
                print(f"[WARN] load_sample_files: CSV file not found: {path}", file=sys.stderr)
    if csv_files:
        return _load_official_csv_sample_files(csv_files)

    # Priority 3: generic fallback
    item_dict: Dict[int, Dict[str, Any]] = {}
    user_seq: Dict[int, List[int]] = {}
    for raw_path in sample_files:
        path = Path(raw_path)
        if path.is_dir():
            files = [p for p in sorted(path.rglob("*")) if p.is_file()]
        else:
            resolved = _resolve_path(path)
            if resolved is None:
                print(f"[WARN] load_sample_files: file not found, skipping: {path}", file=sys.stderr)
                continue
            files = [resolved]
        for file_path in files:
            for record in _iter_records(file_path):
                logid = _as_int(_first_key(record, LOGID_KEYS), default=len(item_dict))
                user_id = _as_int(_first_key(record, USER_KEYS), default=logid)
                features = _features_from_record(record)
                item_dict[logid] = {"logid": logid, "user_id": user_id, "features": features, "raw": record}
                user_seq.setdefault(user_id, []).extend(features)
    return item_dict, user_seq


# ==============================================================================
# Required interface: CTRTestSeqDataset
# ==============================================================================

class CTRTestSeqDataset:
    """Test dataset yielding individual samples with user history context.

    Supports three data modes:
      - cached_batch: pre-processed .pt shards (pass-through)
      - official_csv: slot-based features from competition CSV format
      - generic: feature-id sequences from arbitrary file formats
    """

    def __init__(self, test_logids_ordered, item_dict, user_seq, max_feasign_per_slot, max_ctx_len):
        self.item_dict = item_dict or {}
        self.user_seq = user_seq or {}
        self.cached_batches = [v["cached_batch"] for _, v in sorted(self.item_dict.items()) if isinstance(v, Mapping) and "cached_batch" in v]
        self.test_logids_ordered = [_as_int(x) for x in test_logids_ordered]
        if self.cached_batches and not self.test_logids_ordered:
            self.test_logids_ordered = list(range(len(self.cached_batches)))
        self.pred_logids = set(self.test_logids_ordered)
        self.max_feasign_per_slot = max_feasign_per_slot
        self.max_ctx_len = int(max_ctx_len or 1)
        self.official_csv = bool(self.item_dict) and all(
            isinstance(v, Mapping) and {"userid", "signs", "slots"}.issubset(v.keys())
            for v in self.item_dict.values()
        )
        self.user_items: Dict[int, List[Tuple[int, Dict[int, List[int]], float]]] = {}
        if self.official_csv:
            user_items: Dict[int, List[Tuple[int, Dict[int, List[int]], float]]] = defaultdict(list)
            for raw_logid, rec in self.item_dict.items():
                logid = int(rec.get("logid", raw_logid))
                userid = int(rec["userid"])
                feasign: Dict[int, List[int]] = defaultdict(list)
                signs = rec["signs"].tolist() if isinstance(rec["signs"], np.ndarray) else list(rec["signs"])
                slots = rec["slots"].tolist() if isinstance(rec["slots"], np.ndarray) else list(rec["slots"])
                for slot, sign in zip(slots, signs):
                    feasign[int(slot)].append(int(sign))
                if isinstance(max_feasign_per_slot, Mapping):
                    feasign = {
                        slot: signs[:max_feasign_per_slot[slot]]
                        if max_feasign_per_slot.get(slot, -1) != -1 else signs
                        for slot, signs in feasign.items()
                    }
                user_items[userid].append((logid, dict(feasign), float(rec.get("clk", 0))))
            self.user_items = dict(user_items)
            self.user_ids = sorted(self.user_items.keys())
            self.num_users = len(self.user_ids)
            self.total_samples = len(self.item_dict)
            self.max_slot_id = 28
        else:
            self.user_ids = []
            self.num_users = 0
            self.total_samples = len(self.item_dict)
            self.max_slot_id = 28 if self.cached_batches else max(0, self.max_ctx_len - 1)

    def __len__(self) -> int:
        if self.cached_batches:
            return len(self.cached_batches)
        if self.official_csv:
            return len(self.user_ids)
        return len(self.test_logids_ordered)

    def __getitem__(self, idx: int) -> Dict[str, Any]:
        if self.cached_batches:
            return self.cached_batches[idx]
        if self.official_csv:
            userid = self.user_ids[idx]
            items = list(self.user_items[userid])
            if userid in self.user_seq:
                seq_order = {logid: i for i, logid in enumerate(self.user_seq[userid])}
                items.sort(key=lambda x: seq_order.get(x[0], x[0]))
            else:
                items.sort(key=lambda x: x[0])
            logids = [logid for logid, _, _ in items]
            return {
                "userid": userid,
                "logids": logids,
                "feasigns": [feasign for _, feasign, _ in items],
                "labels": [label for _, _, label in items],
                "pred_mask": [1 if not self.pred_logids or logid in self.pred_logids else 0 for logid in logids],
            }
        logid = self.test_logids_ordered[idx]
        record = self.item_dict.get(logid, {"logid": logid, "user_id": logid, "features": [0]})
        user_id = _as_int(record.get("user_id"), default=logid)
        history = list(self.user_seq.get(user_id, []))
        features = list(record.get("features") or [])
        seq = (history + features)[-self.max_ctx_len:] or [0]
        return {"logid": logid, "user_id": user_id, "features": seq, "pred_mask": True}


# ==============================================================================
# Required interface: make_collate_fn
# ==============================================================================

def make_collate_fn(max_slot_id) -> Callable:
    def collate(batch: Sequence[Mapping[str, Any]]) -> Dict[str, Any]:
        if batch and all(isinstance(row, Mapping) and _is_cached_batch(row) for row in batch):
            return dict(_prepare_official_batch(_merge_cached_batches(batch), max_slot_id=max_slot_id))
        if batch and all(isinstance(row, Mapping) and {"logids", "feasigns", "labels"}.issubset(row.keys()) for row in batch):
            all_userids = []
            all_logids = []
            all_labels = []
            all_pred_masks = []
            all_feasigns = []
            user_offsets = [0]
            for item in batch:
                for i, logid in enumerate(item["logids"]):
                    all_userids.append(item["userid"])
                    all_logids.append(logid)
                    all_labels.append(item["labels"][i])
                    all_pred_masks.append(item["pred_mask"][i])
                    all_feasigns.append(item["feasigns"][i])
                user_offsets.append(len(all_labels))
            slot_data = {}
            for slot in range(1, int(max_slot_id) + 1):
                values = []
                offsets = [0]
                for feasign in all_feasigns:
                    if slot in feasign:
                        values.extend(feasign[slot])
                    offsets.append(len(values))
                slot_data[slot] = (
                    torch.tensor(values, dtype=torch.long),
                    torch.tensor(offsets, dtype=torch.long),
                )
            result = {
                "userid": torch.tensor(all_userids, dtype=torch.long),
                "logid": torch.tensor(all_logids, dtype=torch.long),
                "label": torch.tensor(all_labels, dtype=torch.float32),
                "pred_mask": torch.tensor(all_pred_masks, dtype=torch.bool),
                "user_offsets": torch.tensor(user_offsets, dtype=torch.long),
            }
            result.update(slot_data)
            return dict(_prepare_official_batch(result, max_slot_id=max_slot_id))
        batch_size = len(batch)
        max_len = max((len(row.get("features", [])) for row in batch), default=1)
        feature_ids = np.zeros((batch_size, max_len), dtype=np.int64)
        attention_mask = np.zeros((batch_size, max_len), dtype=np.bool_)
        for i, row in enumerate(batch):
            vals = [abs(_as_int(x)) for x in row.get("features", [])][-max_len:]
            if vals:
                feature_ids[i, -len(vals):] = vals
                attention_mask[i, -len(vals):] = True
        return {
            "logid": np.asarray([_as_int(row.get("logid")) for row in batch], dtype=np.int64),
            "user_id": np.asarray([_as_int(row.get("user_id")) for row in batch], dtype=np.int64),
            "feature_ids": feature_ids,
            "attention_mask": attention_mask,
            "pred_mask": np.ones((batch_size,), dtype=np.bool_),
        }
    return collate


# ==============================================================================
# Official Model Architecture (v1.3 optimized)
# ==============================================================================

class RepEncoder(nn.Module):
    def __init__(self, vocab_size, emb_dim, padding_idx=0, slot_num=0, d_model=0):
        super().__init__()
        self.emb = nn.Embedding(num_embeddings=vocab_size, embedding_dim=emb_dim, padding_idx=padding_idx)
        self.emb_dim = emb_dim
        self.slot_num = slot_num
        self.input_norm = nn.LayerNorm(slot_num * emb_dim)
        self.linear = nn.Linear(in_features=slot_num * emb_dim, out_features=d_model)

    def _pool_slot(self, values, offsets, is_single_value: bool):
        offsets = offsets.to(values.device, dtype=torch.long, non_blocking=True)
        rows = max(int(offsets.numel()) - 1, 0)
        if rows == 0:
            return self.emb.weight.new_zeros((0, self.emb_dim))
        max_idx = self.emb.num_embeddings - 1
        if int(values.numel()) == 0:
            return self.emb.weight.new_zeros((rows, self.emb_dim))
        values = values.to(dtype=torch.long).clamp(0, max_idx)
        if is_single_value and int(values.numel()) == rows:
            return self.emb(values)
        return F.embedding_bag(
            values,
            self.emb.weight,
            offsets,
            mode="sum",
            include_last_offset=True,
        )

    def forward(self, batch):
        pooled_embs = []
        single_value_slots = set(batch.get("_single_value_slot_indices", ())) if isinstance(batch, Mapping) else set()
        empty_slots = set(batch.get("_empty_slot_indices", ())) if isinstance(batch, Mapping) else set()
        rows = None
        pred_mask = batch.get("pred_mask") if isinstance(batch, Mapping) else None
        if pred_mask is not None and hasattr(pred_mask, "shape"):
            rows = int(pred_mask.shape[0])
        for i in range(self.slot_num):
            values, offsets = batch[i + 1]
            if i in empty_slots:
                if rows is None:
                    rows = max(int(offsets.numel()) - 1, 0)
                res = self.emb.weight.new_zeros((rows, self.emb_dim))
            else:
                res = self._pool_slot(values, offsets, i in single_value_slots)
                if rows is None:
                    rows = int(res.shape[0])
            pooled_embs.append(res)
        fused_embs = torch.cat(pooled_embs, dim=1)
        norm_emb = self.input_norm(fused_embs)
        return self.linear(norm_emb)


def scaled_dot_product(q, k, v, extension):
    d = q.size(-1)
    scores = torch.matmul(q, k.transpose(-2, -1)) / math.sqrt(d)
    if extension is not None and "mask" in extension:
        mask = extension["mask"]
        scores = scores.masked_fill(mask == 0, float("-inf"))
    attn = torch.softmax(scores, dim=-1)
    return torch.matmul(attn, v)


class Expert(nn.Module):
    def __init__(self, d_model, dim_ff):
        super().__init__()
        self.fc1 = nn.Linear(d_model, dim_ff)
        self.fc2 = nn.Linear(dim_ff, d_model)

    def forward(self, x):
        return self.fc2(F.relu(self.fc1(x)))


class TopKGate(nn.Module):
    def __init__(self, d_model, num_experts, k=2, noisy_gating=True):
        super().__init__()
        self.w_g = nn.Linear(d_model, num_experts)
        self.num_experts = num_experts
        self.k = k
        self.noisy_gating = noisy_gating

    def forward(self, x):
        logits = self.w_g(x)
        if self.noisy_gating and self.training:
            logits = logits + torch.randn_like(logits) * 0.1
        topk_logits, topk_idx = torch.topk(logits, self.k, dim=-1)
        log_denom = torch.logsumexp(logits, dim=-1, keepdim=True)
        topk_score = torch.exp(topk_logits - log_denom)
        return topk_idx, topk_score


class SMoE(nn.Module):
    def __init__(self, d_model, dim_ff, num_experts, k=2):
        super().__init__()
        self.num_experts = num_experts
        self.k = k
        self.experts = nn.ModuleList([Expert(d_model, dim_ff) for _ in range(num_experts)])
        self.gate = TopKGate(d_model, num_experts, k=k)

    def forward(self, x):
        B, S, D = x.shape
        topk_idx, topk_score = self.gate(x)
        out = torch.zeros_like(x)
        x_flat = x.reshape(-1, D)
        idx_flat = topk_idx.reshape(-1, self.k)
        score_flat = topk_score.reshape(-1, self.k)
        out_flat = out.reshape(-1, D)
        for i in range(self.num_experts):
            mask = (idx_flat == i)
            if not mask.any():
                continue
            token_idx, k_idx = mask.nonzero(as_tuple=True)
            expert_out = self.experts[i](x_flat[token_idx])
            weight = score_flat[token_idx, k_idx].unsqueeze(-1)
            out_flat.index_add_(0, token_idx, expert_out * weight)
        return out, x.new_zeros(())


class TransformerEncoder(nn.Module):
    def __init__(self, d_model, n_heads, num_layers, dim_ff, act="relu", attention_fn=scaled_dot_product):
        super().__init__()
        self.d_model = d_model
        self.n_heads = n_heads
        self.head_dim = d_model // n_heads
        self.num_layers = num_layers
        assert d_model % n_heads == 0
        self.qkv_proj = nn.ModuleList([nn.Linear(d_model, 3 * d_model) for _ in range(num_layers)])
        self.out_proj = nn.ModuleList([nn.Linear(d_model, d_model) for _ in range(num_layers)])
        self.ffn1 = nn.ModuleList([nn.Linear(d_model, dim_ff) for _ in range(num_layers)])
        self.ffn2 = nn.ModuleList([nn.Linear(dim_ff, d_model) for _ in range(num_layers)])
        self.norm1 = nn.ModuleList([nn.LayerNorm(d_model) for _ in range(num_layers)])
        self.norm2 = nn.ModuleList([nn.LayerNorm(d_model) for _ in range(num_layers)])
        self.act = getattr(F, act)
        self.attention_fn = attention_fn
        self.moe = nn.ModuleList([SMoE(d_model, dim_ff, num_experts=8, k=2) for _ in range(num_layers)])

    def _dense_attention(self, q, k, v, extension):
        return self.attention_fn(q, k, v, extension)

    def _block_causal_attention(self, q, k, v, user_offsets):
        B, H, S, HD = q.shape
        if B != 1 or user_offsets is None:
            return None
        if torch.is_tensor(user_offsets):
            offsets = user_offsets.detach().cpu().tolist()
        else:
            offsets = list(user_offsets)
        if len(offsets) < 2 or int(offsets[0]) != 0 or int(offsets[-1]) != S:
            return None
        out = q.new_empty(q.shape)
        for start, end in zip(offsets[:-1], offsets[1:]):
            start = int(start)
            end = int(end)
            if end <= start:
                continue
            q_u = q[:, :, start:end, :]
            k_u = k[:, :, start:end, :]
            v_u = v[:, :, start:end, :]
            try:
                out[:, :, start:end, :] = F.scaled_dot_product_attention(
                    q_u,
                    k_u,
                    v_u,
                    attn_mask=None,
                    dropout_p=0.0,
                    is_causal=True,
                )
            except Exception:
                length = end - start
                mask = torch.ones((length, length), dtype=torch.bool, device=q.device).tril()
                scores = torch.matmul(q_u, k_u.transpose(-2, -1)) / math.sqrt(HD)
                scores = scores.masked_fill(mask.view(1, 1, length, length) == 0, float("-inf"))
                attn = torch.softmax(scores, dim=-1)
                out[:, :, start:end, :] = torch.matmul(attn, v_u)
        return out

    def forward(self, x, extension=None, user_offsets=None):
        x = x.unsqueeze(0)
        B, S, D = x.shape
        if user_offsets is not None:
            if torch.is_tensor(user_offsets):
                block_offsets = user_offsets.detach().cpu().tolist()
            else:
                block_offsets = list(user_offsets)
        else:
            block_offsets = None
        moe_loss_total = x.new_zeros(())
        for i in range(self.num_layers):
            residual = x
            x = self.norm1[i](x)
            qkv = self.qkv_proj[i](x)
            qkv = qkv.view(B, S, self.n_heads, 3 * self.head_dim)
            qkv = qkv.permute(0, 2, 1, 3)
            q, k, v = torch.split(qkv, self.head_dim, dim=-1)
            attn_out = self._block_causal_attention(q, k, v, block_offsets)
            if attn_out is None:
                attn_out = self._dense_attention(q, k, v, extension)
            attn_out = attn_out.permute(0, 2, 1, 3).reshape(B, S, D)
            x = residual + self.out_proj[i](attn_out)
            residual = x
            x = self.norm2[i](x)
            moe_out, moe_loss = self.moe[i](x)
            x = residual + moe_out
            moe_loss_total = moe_loss_total + moe_loss
        return x, moe_loss_total


class CTRModel(nn.Module):
    def __init__(self, rep_encoder, seq_encoder, d_model):
        super().__init__()
        self.rep_encoder = rep_encoder
        self.seq_encoder = seq_encoder
        self.d_model = d_model
        self.linear = nn.Linear(d_model, 1)

    def get_sequence_causal_mask(self, seq_info):
        lengths = seq_info[1:] - seq_info[:-1]
        lengths = lengths.view(-1)
        indices = torch.cumsum(torch.ones_like(lengths), dim=0) - 1
        result = torch.repeat_interleave(indices, lengths)
        a = result.view(1, -1) - result.view(-1, 1)
        return torch.tril((a == 0).to(torch.int32)).bool()

    def forward(self, batch):
        seq_input = self.rep_encoder(batch)
        encoder_output, moe_loss = self.seq_encoder(
            x=seq_input,
            user_offsets=batch.get("user_offsets"),
        )
        encoder_output_dim = encoder_output.shape[-1]
        encoder_output = encoder_output.reshape(1, -1, encoder_output_dim).squeeze(0)
        pred_index = batch.get("_pred_index") if isinstance(batch, Mapping) else None
        num_predictions = batch.get("_num_predictions") if isinstance(batch, Mapping) else None
        if pred_index is not None and num_predictions is not None:
            rows = int(encoder_output.shape[0])
            num_predictions = int(num_predictions)
            if 0 < num_predictions < rows:
                if not torch.is_tensor(pred_index):
                    pred_index = torch.as_tensor(pred_index, dtype=torch.long, device=encoder_output.device)
                elif pred_index.device != encoder_output.device:
                    pred_index = pred_index.to(encoder_output.device, non_blocking=True)
                pred_logits = encoder_output.new_zeros((rows, 1))
                selected = torch.clamp(self.linear(encoder_output.index_select(0, pred_index.long())), min=-15.0, max=15.0)
                pred_logits.index_copy_(0, pred_index.long(), selected)
                return pred_logits, moe_loss
        pred = self.linear(encoder_output)
        pred_logits = torch.clamp(pred, min=-15.0, max=15.0)
        return pred_logits, moe_loss


def _build_official_model() -> nn.Module:
    emb_dim = 512
    slot_num = 28
    vocab_size = 5_000_000
    d_model = 512
    n_heads = 8
    num_layers = 8
    dim_ff = 1024
    rep_encoder = RepEncoder(
        vocab_size=vocab_size,
        emb_dim=emb_dim,
        padding_idx=0,
        slot_num=slot_num,
        d_model=d_model,
    )
    seq_encoder = TransformerEncoder(
        d_model=d_model,
        n_heads=n_heads,
        num_layers=num_layers,
        dim_ff=dim_ff,
        act="relu",
    )
    return CTRModel(rep_encoder, seq_encoder, d_model=d_model)


# ==============================================================================
# GRAB Model Architecture (fallback for non-official checkpoints)
# ==============================================================================

class GRABConfig:
    vocab_size: int = 1_000_003
    d_model: int = 64
    n_layers: int = 4
    n_heads: int = 4
    d_ff: int = 128
    n_channels: int = 2
    max_seq_len: int = 2048
    sliding_window: int = 512
    dropout: float = 0.0


class GRABAttention(nn.Module):
    def __init__(self, d_model: int, n_heads: int, sliding_window: int = 512):
        super().__init__()
        assert d_model % n_heads == 0
        self.n_heads = n_heads
        self.head_dim = d_model // n_heads
        self.sliding_window = sliding_window
        self.q_proj = nn.Linear(d_model, d_model, bias=False)
        self.k_proj = nn.Linear(d_model, d_model, bias=False)
        self.v_proj = nn.Linear(d_model, d_model, bias=False)
        self.out_proj = nn.Linear(d_model, d_model, bias=False)

    def forward(self, x: torch.Tensor):
        B, L, D = x.shape
        q = self.q_proj(x).view(B, L, self.n_heads, self.head_dim).transpose(1, 2)
        k = self.k_proj(x).view(B, L, self.n_heads, self.head_dim).transpose(1, 2)
        v = self.v_proj(x).view(B, L, self.n_heads, self.head_dim).transpose(1, 2)
        total_L = L

        # mask: True = do NOT attend (PyTorch convention)
        mask = torch.ones(L, total_L, device=x.device, dtype=torch.bool).triu(diagonal=1)
        if self.sliding_window > 0 and total_L > self.sliding_window:
            win_start = max(0, total_L - self.sliding_window)
            mask[:, :win_start] = True

        if hasattr(F, "scaled_dot_product_attention"):
            out = F.scaled_dot_product_attention(q, k, v, attn_mask=mask.unsqueeze(0).unsqueeze(0), dropout_p=0.0)
        else:
            scale = self.head_dim ** -0.5
            attn = (q @ k.transpose(-2, -1)) * scale
            attn = attn.masked_fill(mask.unsqueeze(0).unsqueeze(0), float("-inf"))
            attn = F.softmax(attn, dim=-1)
            out = attn @ v

        out = out.transpose(1, 2).contiguous().view(B, L, D)
        return self.out_proj(out)


class GRABFFN(nn.Module):
    def __init__(self, d_model: int, d_ff: int):
        super().__init__()
        self.fc1 = nn.Linear(d_model, d_ff)
        self.fc2 = nn.Linear(d_ff, d_model)

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        return self.fc2(F.relu(self.fc1(x)))


class GRABChannel(nn.Module):
    def __init__(self, d_model: int, n_heads: int, d_ff: int, sliding_window: int):
        super().__init__()
        self.norm1 = nn.LayerNorm(d_model)
        self.attn = GRABAttention(d_model, n_heads, sliding_window)
        self.norm2 = nn.LayerNorm(d_model)
        self.ffn = GRABFFN(d_model, d_ff)

    def forward(self, x: torch.Tensor):
        x = x + self.attn(self.norm1(x))
        x = x + self.ffn(self.norm2(x))
        return x


class GRABLayer(nn.Module):
    def __init__(self, cfg: GRABConfig):
        super().__init__()
        C = cfg.n_channels
        self.n_channels = C
        self.channels = nn.ModuleList([
            GRABChannel(cfg.d_model, cfg.n_heads, cfg.d_ff, cfg.sliding_window) for _ in range(C)
        ])
        self.gate = nn.Linear(cfg.d_model * C, C * C)

    def forward(self, channel_inputs):
        C = self.n_channels
        channel_out: List[torch.Tensor] = []
        for c in range(C):
            channel_out.append(self.channels[c](channel_inputs[c]))
        targets = [ch[:, -1:, :] for ch in channel_out]
        gate_input = torch.cat(targets, dim=-1)
        gate_weights = torch.sigmoid(self.gate(gate_input)).view(-1, 1, C, C)
        mixed = list(targets)
        for c in range(C):
            contribution = torch.zeros_like(targets[c])
            for i in range(C):
                if i != c:
                    contribution = contribution + gate_weights[:, :, i, c] * targets[i]
            mixed[c] = targets[c] + contribution
        result = []
        for c in range(C):
            ch = channel_out[c]
            result.append(torch.cat([ch[:, :-1, :], mixed[c]], dim=1))
        return result


class GRABModel(nn.Module):
    def __init__(self, cfg: GRABConfig):
        super().__init__()
        self.cfg = cfg
        self.embedding = nn.Embedding(cfg.vocab_size, cfg.d_model, padding_idx=0)
        self.layers = nn.ModuleList([GRABLayer(cfg) for _ in range(cfg.n_layers)])
        self.head = nn.Sequential(
            nn.LayerNorm(cfg.d_model * cfg.n_channels),
            nn.Linear(cfg.d_model * cfg.n_channels, 32),
            nn.ReLU(),
            nn.Linear(32, 1),
        )

    def forward(self, batch: Mapping[str, Any]):
        ids = batch["feature_ids"]
        mask = batch.get("attention_mask")
        ids = ids.clamp(0, self.cfg.vocab_size - 1)
        x = self.embedding(ids)
        if mask is not None:
            x = x * mask.unsqueeze(-1).to(dtype=x.dtype)
        channel_inputs = [x] * self.cfg.n_channels
        for layer in self.layers:
            channel_inputs = layer(channel_inputs)
        last_positions = [ch[:, -1:, :] for ch in channel_inputs]
        combined = torch.cat(last_positions, dim=-1)
        logits = self.head(combined)
        return logits.squeeze(1), logits.new_zeros(())


# ==============================================================================
# HashCTRModel — last-resort fallback
# ==============================================================================

class HashCTRModel(nn.Module):
    def __init__(self, vocab_size: int = 1_000_003, d_model: int = 64):
        super().__init__()
        self.vocab_size = int(vocab_size)
        self.embedding = nn.Embedding(self.vocab_size, d_model, padding_idx=0)
        self.head = nn.Sequential(
            nn.LayerNorm(d_model),
            nn.Linear(d_model, d_model),
            nn.ReLU(),
            nn.Linear(d_model, 1),
        )

    def forward(self, batch: Mapping[str, Any]):
        ids = batch["feature_ids"].remainder(self.vocab_size)
        mask = batch.get("attention_mask")
        emb = self.embedding(ids)
        if mask is None:
            pooled = emb.mean(dim=1)
        else:
            mask_f = mask.to(dtype=emb.dtype).unsqueeze(-1)
            pooled = (emb * mask_f).sum(dim=1) / mask_f.sum(dim=1).clamp_min(1.0)
        logits = self.head(pooled)
        return logits, logits.new_zeros(())


# ==============================================================================
# ModelAdapter — wraps any model to enforce (logits, moe_loss) output contract
# ==============================================================================

class ModelAdapter(nn.Module):
    def __init__(self, model: nn.Module):
        super().__init__()
        self.model = model

    def forward(self, batch: Mapping[str, Any]):
        with torch.inference_mode():
            pred_mask = batch.get("pred_mask") if isinstance(batch, Mapping) else None
            logid = batch.get("logid") if isinstance(batch, Mapping) else None
            has_predictions = batch.get("_has_predictions") if isinstance(batch, Mapping) else None
            if has_predictions is False or (has_predictions is None and pred_mask is not None and logid is not None):
                no_predictions = has_predictions is False
                if not no_predictions:
                    mask_tensor = pred_mask if torch.is_tensor(pred_mask) else torch.as_tensor(pred_mask)
                    no_predictions = mask_tensor.numel() > 0 and not bool(mask_tensor.bool().any().item())
                if no_predictions:
                    rows = int(logid.shape[0]) if hasattr(logid, "shape") else len(logid)
                    device = logid.device if torch.is_tensor(logid) else _object_device(batch)
                    return torch.zeros((rows, 1), dtype=torch.float32, device=device), torch.zeros((), device=device)
            out = self.model(batch)
            if isinstance(out, tuple):
                if len(out) >= 2:
                    return out[0], out[1]
                return out[0], torch.zeros((), device=_object_device(batch))
            if isinstance(out, Mapping):
                logits = None
                for key in ("logits", "pred", "prediction", "output"):
                    if key in out:
                        logits = out[key]
                        break
                if logits is None:
                    raise RuntimeError("model output mapping does not contain logits/pred/prediction/output")
                return logits, out.get("moe_loss", torch.zeros((), device=_object_device(batch)))
            return out, torch.zeros((), device=_object_device(batch))


def _object_device(obj: Any):
    if torch is not None and torch.is_tensor(obj):
        return obj.device
    if isinstance(obj, Mapping):
        for value in obj.values():
            device = _object_device(value)
            if device is not None:
                return device
    if isinstance(obj, (list, tuple)):
        for value in obj:
            device = _object_device(value)
            if device is not None:
                return device
    return torch.device("cpu") if torch is not None else None


# ==============================================================================
# State dict utilities
# ==============================================================================

def _extract_state_dict(ckpt: Mapping[str, Any]) -> Mapping[str, Any] | None:
    for key in STATE_DICT_KEYS:
        value = ckpt.get(key)
        if isinstance(value, Mapping):
            return value
    if ckpt and all(torch.is_tensor(v) for v in ckpt.values()):
        return ckpt
    return None


def _clean_state_dict_keys(state_dict: Mapping[str, Any]) -> Dict[str, Any]:
    cleaned: Dict[str, Any] = {}
    for key, value in state_dict.items():
        key = str(key)
        for prefix in ("module.", "model.", "net."):
            if key.startswith(prefix):
                key = key[len(prefix):]
        cleaned[key] = value
    return cleaned


def _load_state_dict_strict(model: nn.Module, state_dict: Mapping[str, Any]) -> None:
    try:
        model.load_state_dict(state_dict)
        return
    except RuntimeError:
        cleaned = _clean_state_dict_keys(state_dict)
        original_keys = [str(k) for k in state_dict.keys()]
        if list(cleaned.keys()) == original_keys:
            raise
        model.load_state_dict(cleaned)


def _try_load_state_dict_into_existing(model: nn.Module, ckpt: Mapping[str, Any]) -> bool:
    state_dict = _extract_state_dict(ckpt)
    if state_dict is None:
        return False
    _load_state_dict_strict(model, state_dict)
    return True


def _infer_vocab_size(state_dict: Mapping[str, Any] | None, default: int = 1_000_003) -> int:
    if not state_dict:
        return default
    for key, value in state_dict.items():
        if torch is not None and torch.is_tensor(value) and value.ndim == 2:
            if "embed" in key.lower():
                return int(value.shape[0])
    return default


def _infer_grab_config(state_dict: Mapping[str, Any] | None) -> GRABConfig:
    cfg = GRABConfig()
    cfg.vocab_size = _infer_vocab_size(state_dict, cfg.vocab_size)
    if state_dict:
        for key, value in state_dict.items():
            if not (torch is not None and torch.is_tensor(value)):
                continue
            if value.ndim == 2:
                if "q_proj" in key or "k_proj" in key or "v_proj" in key:
                    cfg.d_model = int(value.shape[0])
                elif "fc1" in key and "ffn" in key:
                    cfg.d_ff = int(value.shape[0])
                    cfg.d_model = int(value.shape[1])
                elif "fc2" in key and "ffn" in key:
                    cfg.d_model = int(value.shape[0])
                    cfg.d_ff = int(value.shape[1])
            if "embedding" in key and value.ndim == 2:
                cfg.d_model = int(value.shape[1])
                cfg.vocab_size = int(value.shape[0])
    return cfg


# ==============================================================================
# Required interface: load_model
# ==============================================================================

def load_model(ckpt_path: Path):
    """Load model from checkpoint.

    Loading priority:
      1. Full nn.Module in checkpoint -> use directly
      2. Dict with 'model'/'net' key containing nn.Module -> extract
      3. State dict -> try official CTRModel, then GRABModel, then HashCTRModel
    """
    _require_torch()
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    torch.set_grad_enabled(False)
    if torch.cuda.is_available():
        torch.backends.cuda.matmul.allow_tf32 = True
        torch.backends.cudnn.allow_tf32 = True

    ckpt_path = Path(ckpt_path)
    if not ckpt_path.exists():
        resolved = _resolve_path(ckpt_path)
        if resolved is not None:
            print(f"[INFO] load_model: resolved checkpoint path to: {resolved}", file=sys.stderr)
            ckpt_path = resolved
    if not ckpt_path.exists():
        raise FileNotFoundError(f"checkpoint not found: {ckpt_path}")

    try:
        ckpt = torch.load(ckpt_path, map_location="cpu", weights_only=False)
    except TypeError:
        ckpt = torch.load(ckpt_path, map_location="cpu")

    model = None
    epoch = "?"
    if isinstance(ckpt, nn.Module):
        model = ckpt
    elif isinstance(ckpt, Mapping):
        epoch = ckpt.get("epoch", "?")
        for key in MODEL_KEYS:
            value = ckpt.get(key)
            if isinstance(value, nn.Module):
                model = value
                _try_load_state_dict_into_existing(model, ckpt)
                break
        if model is None:
            state_dict = _extract_state_dict(ckpt)
            if state_dict is not None:
                # 3a: Try official CTRModel
                try:
                    model = _build_official_model()
                    _load_state_dict_strict(model, state_dict)
                except Exception:
                    # 3b: Try GRABModel
                    try:
                        cfg = _infer_grab_config(state_dict)
                        model = GRABModel(cfg)
                        cleaned = _clean_state_dict_keys(state_dict)
                        missing, unexpected = model.load_state_dict(cleaned, strict=False)
                        if missing:
                            print(f"[load_model] GRABModel missing keys: {len(missing)}", file=sys.stderr)
                    except Exception:
                        # 3c: Final fallback
                        model = HashCTRModel(vocab_size=_infer_vocab_size(state_dict))
                        cleaned = _clean_state_dict_keys(state_dict)
                        model.load_state_dict(cleaned, strict=False)

    if model is None:
        raise RuntimeError(
            "ckpt.pt did not contain a loadable torch.nn.Module or recognized state_dict. "
            "infer.py tried: official CTRModel, GRABModel, HashCTRModel."
        )

    print(f"[INFO] Loaded checkpoint from {ckpt_path} (epoch={epoch})")
    model.eval().to(device)

    if torch.cuda.is_available():
        torch.backends.cudnn.benchmark = True

    # torch.compile: JIT kernel fusion (safe, 10-30% speedup)
    if hasattr(torch, "compile"):
        try:
            model = torch.compile(model, mode="reduce-overhead")
        except Exception:
            pass

    return ModelAdapter(model), device


# ==============================================================================
# Required interface: move_batch_to_device
# ==============================================================================

def move_batch_to_device(batch, device):
    _require_torch()
    list_metadata_keys = {
        "_active_slot_indices",
        "_empty_slot_indices",
        "_single_value_slot_indices",
        "_variable_slot_indices",
    }

    def _to_tensor_if_plain_numeric_sequence(value: Any):
        if isinstance(value, np.ndarray):
            return torch.from_numpy(value)
        if isinstance(value, (list, tuple)) and value and all(isinstance(x, (int, bool, np.integer, np.bool_)) for x in value):
            return torch.tensor(value)
        return None

    def move(obj: Any, key: Any = None):
        if key == "_has_predictions":
            return bool(obj)
        if key == "_num_predictions":
            return int(obj)
        if key in list_metadata_keys:
            return list(obj) if isinstance(obj, (list, tuple)) else obj
        if torch.is_tensor(obj):
            tensor = obj
        else:
            tensor = _to_tensor_if_plain_numeric_sequence(obj)
        if tensor is not None:
            if key in {"pred_mask", "attention_mask"}:
                tensor = tensor.bool()
            elif key in {"logid", "userid", "user_id", "feature_ids", "user_offsets", "_pred_index"} or isinstance(key, int):
                tensor = tensor.long()
            if key == "user_offsets":
                return tensor.cpu()
            return tensor.to(device, non_blocking=True)
        if isinstance(obj, Mapping):
            return {k: move(v, k) for k, v in obj.items()}
        if isinstance(obj, tuple):
            return tuple(move(v, key) for v in obj)
        if isinstance(obj, list):
            return [move(v, key) for v in obj]
        return obj

    return move(batch)


# ==============================================================================
# Inference pipeline
# ==============================================================================

def _find_cached_batch_files(code_root: Path) -> List[Path]:
    code_root = Path(code_root)
    try:
        infer_dir = Path(__file__).resolve().parent
    except Exception:
        infer_dir = code_root
    candidates = [
        code_root / "dataset" / "cached_batches",
        code_root / "cached_batches",
        code_root / "official" / "dataset_cached_probe" / "dataset" / "cached_batches",
        infer_dir / "dataset" / "cached_batches",
        infer_dir / "cached_batches",
        infer_dir / "official" / "dataset_cached_probe" / "dataset" / "cached_batches",
        Path.cwd() / "dataset" / "cached_batches",
        Path.cwd() / "cached_batches",
        Path.cwd() / "official" / "dataset_cached_probe" / "dataset" / "cached_batches",
    ]
    seen: set[str] = set()
    for directory in candidates:
        key = str(directory.resolve())
        if key in seen:
            continue
        seen.add(key)
        if directory.exists():
            files = sorted(directory.glob("shard_*.pt"))
            if files:
                return files
    return []


def _run_model(model: nn.Module, batch: Mapping[str, Any]):
    with torch.inference_mode():
        logits, _ = model(batch)
    if logits.ndim > 1 and logits.shape[-1] == 1:
        logits = logits.squeeze(-1)
    return logits


def _write_prediction_values(preds: Sequence[float], output_path: Path) -> None:
    with output_path.open("w", encoding="utf-8", newline="") as f:
        for pred in preds:
            f.write(f"{float(pred):.8f}\n")


def _read_test_logids_in_order(test_file: Path) -> List[int]:
    logids: List[int] = []
    with test_file.open("r", encoding="utf-8") as f:
        for line in f:
            line = line.strip()
            if line:
                logids.append(int(line.split(",", 1)[0]))
    return logids


def _order_prediction_values(predictions: Sequence[Tuple[int, float]], code_root: Path) -> List[float]:
    test_file = _resolve_path(code_root / "dataset" / "test.csv")
    if test_file is None:
        test_file = code_root / "test.csv"
    if not test_file.exists():
        return [float(prob) for _, prob in predictions]
    preds_by_logid: Dict[int, List[float]] = defaultdict(list)
    for logid, prob in predictions:
        preds_by_logid[int(logid)].append(float(prob))
    ordered: List[float] = []
    for logid in _read_test_logids_in_order(test_file):
        values = preds_by_logid.get(logid)
        if not values:
            raise RuntimeError(f"missing prediction for logid {logid}")
        ordered.append(values.pop(0))
    return ordered


def run_inference(code_root: Path) -> Path:
    _require_torch()
    code_root = Path(code_root)
    shard_files = _find_cached_batch_files(code_root)
    if not shard_files:
        raise FileNotFoundError(
            f"cached batch shards not found. Searched under: {code_root}/dataset/cached_batches, "
            f"{code_root}/cached_batches, and infer.py directory"
        )
    ckpt_path = code_root / "ckpt.pt"
    if not ckpt_path.exists():
        resolved = _resolve_path(ckpt_path)
        if resolved is not None:
            print(f"[INFO] run_inference: resolved checkpoint path to: {resolved}")
            ckpt_path = resolved
    if not ckpt_path.exists():
        raise FileNotFoundError(f"checkpoint not found: {code_root / 'ckpt.pt'}")

    print(f"[INFO] loading cached batch shards from {shard_files[0].parent}")
    model, device = load_model(ckpt_path)
    print(f"[INFO] Model ready. Device: {device}")

    predictions: List[Tuple[int, float]] = []
    for shard_path in shard_files:
        batches = _load_cached_batches_from_files([shard_path])
        print(f"[INFO] loaded {len(batches)} batches from {shard_path.name}")
        for batch in batches:
            pred_mask_cpu = batch["pred_mask"].bool() if torch.is_tensor(batch["pred_mask"]) else torch.as_tensor(batch["pred_mask"], dtype=torch.bool)
            if not bool(pred_mask_cpu.any().item()):
                continue
            batch = dict(_prepare_official_batch(batch, max_slot_id=28))
            if batch.get("_has_predictions", True) is False:
                continue
            moved = move_batch_to_device(batch, device)
            logits = _run_model(model, moved)
            pred_mask = moved["pred_mask"].bool()
            probs = torch.sigmoid(logits[pred_mask]).detach().cpu().float().tolist()
            logids = moved["logid"][pred_mask].detach().cpu().long().tolist()
            predictions.extend(zip(logids, probs))

    output_path = code_root / "predict.txt"
    ordered_values = _order_prediction_values(predictions, code_root)
    _write_prediction_values(ordered_values, output_path)
    print(f"[INFO] predictions written to {output_path.name}, total: {len(ordered_values)}")
    return output_path


def self_test(code_root: Path) -> None:
    _require_torch()
    shard_files = _find_cached_batch_files(Path(code_root))
    if not shard_files:
        raise FileNotFoundError("self-test requires at least one cached shard; expected official/dataset_cached_probe/... or dataset/cached_batches")
    batches = _load_cached_batches_from_files([shard_files[0]])
    if not batches:
        raise RuntimeError(f"no batches loaded from {shard_files[0]}")
    total_rows = sum(int(batch["logid"].shape[0]) for batch in batches)
    total_preds = sum(int(batch["pred_mask"].sum().item()) for batch in batches)
    moved = move_batch_to_device(batches[0], torch.device("cuda" if torch.cuda.is_available() else "cpu"))
    assert isinstance(moved, dict)
    assert "logid" in moved and "pred_mask" in moved and "user_offsets" in moved
    assert all(slot in moved and isinstance(moved[slot], tuple) and len(moved[slot]) == 2 for slot in range(1, 29))
    assert moved["logid"].shape[0] == moved["pred_mask"].shape[0]
    print(f"[SELF-TEST] shard={shard_files[0].name} batches={len(batches)} rows={total_rows} preds={total_preds}")


def main(argv: Sequence[str] | None = None) -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("code_root", nargs="?", default=str(Path(__file__).resolve().parent))
    parser.add_argument("--self-test", action="store_true")
    args = parser.parse_args(argv)
    if args.self_test:
        self_test(Path(args.code_root))
    else:
        run_inference(Path(args.code_root))


if __name__ == "__main__":
    main()
